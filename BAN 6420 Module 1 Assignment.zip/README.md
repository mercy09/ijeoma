import random

# Number of workers
num_workers = 400

# Dynamically create a list of workers with random salaries and gender
workers = []
for i in range(num_workers):
  worker = {
      'id': i + 1,
      'salary': random.uniform(5000, 35000),  # Salary between $5,000 and $35,000
      'gender': random.choice(['Male', 'Female'])
  }
  workers.append(worker)


# Generate payment slips with conditional employee levels and exception handling
for worker in workers:
  try:
    if 10000 < worker['salary'] < 20000:
        worker['level'] = 'A1'
    elif 7500 < worker['salary'] < 30000 and worker['gender'] == 'Female':
        worker['level'] = 'A5-F'
    else:
        worker['level'] = 'Other' #Default level


    print(f"Payment Slip for Worker ID: {worker['id']}")
    print(f"Salary: ${worker['salary']:.2f}")
    print(f"Gender: {worker['gender']}")
    print(f"Employee Level: {worker['level']}")
    print("-" * 20)

  except (KeyError, TypeError) as e:
    print(f"Error processing worker {worker['id']}: {e}")
    print("-" * 20)
