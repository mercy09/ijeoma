# R script to unzip and display employee details
unzip("Employee_Profile.zip", exdir = "Employee_Profile")

# Get the list of extracted files
files <- list.files("Employee_Profile", full.names = TRUE)

# Read and display the CSV file
if (length(files) > 0) {
  employee_data <- read.csv(files[1], stringsAsFactors = FALSE)
  print(employee_data)
} else {
  print("No files found in the extracted folder.")
}
