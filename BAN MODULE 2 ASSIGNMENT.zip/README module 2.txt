
Salary Data Processing Assignment

Overview

This project processes salary data using Python and R. The Python script imports data, retrieves employee details, processes data using dictionaries, and exports it as a CSV within a zipped folder. The R script unzips the folder and displays the data.

Files

salary_data_processing.py: Python script for data processing

unzip_display_data.R: R script to unzip and display the employee details

Employee Profile.zip: Zipped folder containing employee details

salary_data.csv: Sample salary dataset (ensure this file is in the working directory)

Requirements

Python

pandas

os

zipfile

R

utils

Usage

Python

Run salary_data_processing.py in a Jupyter Notebook or Python environment.

Ensure salary_data.csv is in the working directory.

Provide an employee name when prompted.

The script will generate and zip Employee Profile/employee_details.csv.

R

Run unzip_display_data.R in an R environment.

The script will unzip Employee Profile.zip and display the contents of employee_details.csv.

Submission

Submit the zipped project folder or upload it to GitHub and share the link.

