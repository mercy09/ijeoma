PCA on Breast Cancer Dataset

Overview

This project applies Principal Component Analysis (PCA) to the breast cancer dataset from sklearn.datasets to reduce dimensionality and visualize the data. Additionally, Logistic Regression is implemented to classify cancer types based on the reduced dataset.

Requirements

libraries were installed before running the script:

import numpy pandas matplotlib seaborn scikit-learn


Features

PCA Implementation: Reduces the dataset to 2 principal components.

Data Visualization: Scatter plot was used to visualized the PCA components.

Logistic Regression (Bonus): Trains a model and evaluates classification performance.

Expected Output

A scatter plot visualizing the first two principal components.

Accuracy score, confusion matrix, and classification report for logistic regression