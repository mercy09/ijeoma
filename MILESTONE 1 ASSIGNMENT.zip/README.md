# Policy Management System

## Setup Instructions

1. Clone the repository or download the files.
2. Ensure you have Python installed (version 3.x recommended).
3. Navigate to the project directory.
4. Run the following command to execute the demonstration:
   ```
   python main.py
   ```

## Files Overview
- `policyholder.py`: Defines the `Policyholder` class.
- `product.py`: Defines the `Product` class.
- `payment.py`: Defines the `Payment` class.
- `main.py`: Demonstrates the functionality of the system.

## Features
- Register and manage policyholders.
- Manage insurance products.
- Process and track payments.
